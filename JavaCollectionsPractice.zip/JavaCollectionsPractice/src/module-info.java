/**
 * 
 */
/**
 * 
 */
module JavaCollectionsPractice {
}